package com.example.booksharing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
